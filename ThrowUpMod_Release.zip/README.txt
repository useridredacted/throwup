Throw Up Mod - Installation Instructions
=======================================

This mod gives you:
1. Unlimited paint capacity in your spray cans.
2. The ability to buy unlimited spray paint from the gas stations (stock is always full).
3. The option to draw on very large canvases.

How to Install:
--------------
1. Make sure you have MelonLoader installed for the game "Schedule I".
2. Copy the "ThrowUpMod.dll" file from this folder.
3. Paste it into the game's "Mods" directory.
   - For standard Steam installations, this is typically located at:
     C:\Program Files (x86)\Steam\steamapps\common\Schedule I\Mods\
     (Or wherever your steam library is located: ...\steamapps\common\Schedule I\Mods\)

4. Start the game and enjoy!
